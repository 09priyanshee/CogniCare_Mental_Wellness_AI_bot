document.getElementById("chat-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const submitBtn = document.querySelector('.chat-submit');
    const userInput = document.getElementById("user-input");
    const messagesDiv = document.getElementById("messages");
    const loadingDiv = document.getElementById("loading");
    
    // Disable input during processing
    submitBtn.disabled = true;
    userInput.disabled = true;
    
    const messageText = userInput.value.trim();
    if (!messageText) return;

    // Display user message
    const userMessageDiv = document.createElement("div");
    userMessageDiv.className = "message user";
    userMessageDiv.textContent = messageText;
    messagesDiv.appendChild(userMessageDiv);
    userInput.value = "";

    // Show loading with ARIA announcement
    loadingDiv.style.display = "block";
    loadingDiv.setAttribute("aria-live", "polite");

    try {
        const response = await fetch("/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: messageText }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        // Process and display responses
        data.responses.forEach((responseText) => {
            const botMessageDiv = document.createElement("div");
            botMessageDiv.className = "message bot";
            
            // Enhanced formatting
            let formattedText = responseText
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')  // Bold text
                .replace(/\n/g, '<br>')                            // Line breaks
                .replace(/- /g, '• ')                              // Bullet points
                .replace(/(\d+)\./g, '<em>$1.</em>');             // Numbered lists

            botMessageDiv.innerHTML = formattedText;
            messagesDiv.appendChild(botMessageDiv);
        });

        // Smooth scroll to latest message
        messagesDiv.scrollTo({
            top: messagesDiv.scrollHeight,
            behavior: 'smooth'
        });

    } catch (error) {
        console.error('Error:', error);
        const errorDiv = document.createElement("div");
        errorDiv.className = "message bot error";
        errorDiv.textContent = "⚠️ Connection issue. Please check your network and try again.";
        messagesDiv.appendChild(errorDiv);
    } finally {
        loadingDiv.style.display = "none";
        loadingDiv.removeAttribute("aria-live");
        submitBtn.disabled = false;
        userInput.disabled = false;
        userInput.focus();
    }
});
